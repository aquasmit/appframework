#8tiles

This plugin is used for Windows Phone 8 theme with App Framework UI.  This moves the left nav bar to the bottom and adds "..." to the navbar to activate them.

####Using the plugin

Simply include the plugin and it will auto-detect Windows Phone 8.